package P2CODE;

import java.util.LinkedList;
public class MyMap extends javax.swing.JPanel {
    private MyWorld world1;

    public MyMap() {
        initComponents();
        
        LinkedList< MyPoint > points = new LinkedList< MyPoint >();
        points.add( new MyPoint( 10, 100 ) );
        points.add( new MyPoint( 150, 10 ) );
        points.add( new MyPoint( 290, 100 ) );
        points.add( new MyPoint( 290, 200 ) );
        points.add( new MyPoint( 150, 290 ) );
        points.add( new MyPoint( 10, 200 ) );
        
        LinkedList< MyPoint > points2 = new LinkedList< MyPoint >();
        points2.add( new MyPoint( 400, 100 ) );
        points2.add( new MyPoint( 400, 200 ) );
        points2.add( new MyPoint( 500, 200 ) );
        points2.add( new MyPoint( 500, 100 ) );

        LinkedList< MyPoint > points3 = new LinkedList< MyPoint >();
        points3.add( new MyPoint( 100, 400 ) );
        points3.add( new MyPoint( 300, 500 ) );
        points3.add( new MyPoint( 200, 400 ) );

        LinkedList< MyPoint > points4 = new LinkedList< MyPoint >();
        points4.add( new MyPoint( 250, 500 ) );
        points4.add( new MyPoint( 100, 550) );
        points4.add( new MyPoint( 200, 550 ) );


        MyPolygon region1 = new MyPolygon( points );
        System.out.println( region1.getArea() );

        MyPolygon region2 = new MyPolygon( points2 );
        System.out.println( region2.getArea() );

        MyPolygon region3 = new MyPolygon( points3 );
        System.out.println( region3.getArea() );
        
        MyPolygon region4 = new MyPolygon( points4 );
        System.out.println( region4.getArea() );
        
        LinkedList <MyPolygon> regions1 = new LinkedList< MyPolygon >();;
        regions1.add(region1);
        regions1.add(region2);

        
        LinkedList <MyPolygon> regions2 = new LinkedList< MyPolygon >();;
        regions2.add(region3);
        regions2.add(region4);

        MyContinent Asia = new MyContinent(regions1);
        System.out.println( Asia.getTotalArea() );
        
        MyContinent America = new MyContinent(regions2);
        System.out.println( America.getTotalArea() );
        
        LinkedList <MyContinent> continents = new LinkedList< MyContinent >();
        continents.add(Asia);
        continents.add(America);

        world1 = new MyWorld(continents);
        System.out.println( world1.getTotalArea() );
    }

    private void initComponents() {
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
    }

    public void paint( java.awt.Graphics g ) {
        super.paint( g );
        world1.draw( g );
    }

}

