package P3CODE;
import java.awt.Graphics;

public abstract interface MyRegion {
    public abstract double getArea(); 
    public abstract void draw(Graphics g);
}
