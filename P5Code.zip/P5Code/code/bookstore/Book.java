package bookstore;

import java.sql.Date;

public class Book {
    //atributes
    private String title;
    private String author;
    private Date publiDate;
    private String publiPlace;
    private long ISBN;

    //constructor
    public Book(String tinit, String ath, String publicDate, String puplace, String iSBN2){
        title = tinit;
        author = ath;
        publiDate = publicDate;
        publiPlace = puplace;
        ISBN = iSBN2;
    }

    // methods
    public String getTitle(){
        return title;
    }
    public String getAuthor(){
        return author;
    }
    public Date getPubliDate(){
        return publiDate;
    }
    public String getPubliPlace(){
        return publiPlace;
    }
    public Long getISBN(){
        return ISBN;
    }
    
}
