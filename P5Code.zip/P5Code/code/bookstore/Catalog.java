import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.LinkedList;

import javax.xml.crypto.Data;

import java.sql.Date;

public class Catalog extends BookCollection {
    public Catalog(){   
        LinkedList< String[]> cat = new LinkedList<String[]>();  
        cat = readCatalog("P5CODE/code/books.xml");
        Data aa = new Date();
        for (int i = 0; i<cat.size(); i++){
            String[] book = cat.get(i);
            String title = book[0];
            String author = book[1];
            String PublicDate = book[2];
            try { aa  = new SimpleDateFormat().parse(PublicDate);}
            catch (Expectetion e){}           
            
            String publicPlace = book[3];

            String ISBN = book[4];
            long isbn = Long.parseLong(ISBN);

            String price = book[5];
            double doublePrive = Double.parseDouble(price);
            String Currency = book[6];
            Currency cucurrency = Currency.getInstance( Currency);

            String copies = book[7];
            int intcopies = Integer.parseInt(copies);

            Book book2 = new Book(title, author, PublicDate, publicPlace, ISBN);

            Stock stock = new Stock(book2, copies, price ,Currency);
 
            

        }
    }
}
