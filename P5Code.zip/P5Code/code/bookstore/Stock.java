package bookstore;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Currency;

public class Stock implements StockInterface {
    //attributes
    private Book book;
    private int copies;
    private double price;
    private Currency currency;
    
    //constractor
    public Stock(Book initBook, String copies2, String price2, String currency2){
        book = initBook;
        copies = copies2;
        price = price2;
        currency = currency2;
    }
    // methods
    public Currency getCurrencyInstance(){
        return currency;
    }

    @Override
    public String getBooktitle() {
        return book.getTitle();
    }

    @Override
    public int numberOfCopies() {
        return copies;
    }

    @Override
    public void addCopies(int copies) {
        copies = copies +1 ;
        
    }

    @Override
    public void removeCopies(int numberOfCopies) {
       copies = copies -1;
    }

    @Override
    public double totalPrice() {
        Format formatter = NumberFormat.getCurrencyInstance(); // esto nose si funcionara bien.
        String moneyStr = formatter.format(price);
        Double totalprice = Double.parseDouble(moneyStr);
        return totalprice;
        }
}

    

  
